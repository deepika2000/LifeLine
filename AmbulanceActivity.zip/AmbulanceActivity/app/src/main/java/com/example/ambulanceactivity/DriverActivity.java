package com.example.ambulanceactivity;

import android.content.Intent;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class DriverActivity extends AppCompatActivity {

    private TextInputLayout textInputUserName;
    private TextInputLayout textInputPassword;
    private TextInputLayout textInputConfirmPassword;
    private TextInputLayout textInputPhoneNumber;
    private TextInputLayout textInputLicenseId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver);
        textInputUserName = findViewById(R.id.text_input_username);
        textInputPassword = findViewById(R.id.text_input_password);
        textInputConfirmPassword = findViewById(R.id.text_input_confirmpassword);
        textInputLicenseId = findViewById(R.id.text_input_licenseid);
        textInputPhoneNumber = findViewById(R.id.text_input_phonenumber);
        init();
    }

    private boolean validateUsername() {
        String username = textInputUserName.getEditText().getText().toString().trim();
        if (username.isEmpty()) {
            textInputUserName.setError("Field can't be empty");
            return false;
        } else if (username.length() > 15) {
            textInputUserName.setError("Username too long");
            return false;
        } else {
            textInputUserName.setError(null);
            return true;
        }
    }


    private boolean validatelicenseId() {
        String licenseInput = textInputLicenseId.getEditText().getText().toString().trim();
        if (licenseInput.isEmpty()) {
            textInputLicenseId.setError("Field can't be empty");
            return false;
        } else if (licenseInput.length() > 15) {
            textInputLicenseId.setError("ID too long");
            return false;
        } else {
            textInputLicenseId.setError(null);
            return true;
        }
    }


    private boolean validatePhoneNumber() {
        String phoneNumber = textInputPhoneNumber.getEditText().getText().toString().trim();

        if (phoneNumber.isEmpty()) {
            textInputPhoneNumber.setError("Field can't be empty");
            return false;
        } else if (phoneNumber.length() > 10) {
            textInputPhoneNumber.setError("Invalid Phone Number");
            return false;
        } else {
            textInputPhoneNumber.setError(null);
            return true;
        }
    }

    private boolean validatePassword() {
        String passwordInput = textInputPassword.getEditText().getText().toString().trim();

        if (passwordInput.isEmpty()) {
            textInputPassword.setError("Field can't be empty");
            return false;
        } else {
            textInputPassword.setError(null);
            return true;
        }
    }
    private boolean validateConfirmPassword() {
        String confirmpasswordInput = textInputPassword.getEditText().getText().toString().trim();
        String pass1 = textInputPassword.getEditText().getText().toString();
        String pass2 = textInputConfirmPassword.getEditText().getText().toString();

        if (confirmpasswordInput.isEmpty()) {
            textInputConfirmPassword.setError("Field can't be empty");
            return false;
        } else if (!confirmpasswordInput.isEmpty() && !pass1.equals(pass2)) {
            Toast pass = Toast.makeText(DriverActivity.this,"Passwords don't match", Toast.LENGTH_SHORT);
            pass.show();
            return false;
        } else {
            textInputConfirmPassword.setError(null);
            return true;
        }
    }

    public void confirmInput(View v) {
        if (!validateUsername() | !validatePhoneNumber() |  !validatePassword() | !validateConfirmPassword()) {
            return;
        }
        String input = "Username: " + textInputUserName.getEditText().getText().toString();
        input += "\n";
        input += "LicenseId: " + textInputLicenseId.getEditText().getText().toString();
        input += "\n";
        input += "PhoneNumber: " + textInputPhoneNumber.getEditText().getText().toString();
        input += "\n";
        input += "Password: " + textInputPassword.getEditText().getText().toString();
        Toast.makeText(this, input, Toast.LENGTH_SHORT).show();
    }

    public TextView t2;

    public void init() {
        t2 = (TextView) findViewById(R.id.text2);
        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toy = new Intent(DriverActivity.this,MainActivity.class);
                startActivity(toy);
            }
        });
    }
}
