package com.example.ambulanceactivity;

import android.content.Intent;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class UserActivity extends AppCompatActivity {
    DatabaseHelper myDb;
    public TextView text2;
    Button btn;
    private TextInputLayout textInputEmail;
    private TextInputLayout textInputUserName;
    private TextInputLayout textInputPassword;
    private TextInputLayout textInputConfirmPassword;
    private TextInputLayout textInputPhoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        myDb = new DatabaseHelper(this);
        textInputEmail = findViewById(R.id.text_input_email);
        textInputUserName = findViewById(R.id.text_input_username);
        textInputPassword = findViewById(R.id.text_input_password);
        textInputConfirmPassword = findViewById(R.id.text_input_confirmpassword);
        textInputPhoneNumber = findViewById(R.id.text_input_phonenumber);
        btn = (Button) findViewById(R.id.butt3);
        init();
    }


    public void init() {
        text2 = (TextView) findViewById(R.id.text2);
        text2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toy = new Intent(UserActivity.this, MainActivity.class);
                startActivity(toy);
                boolean isInserted = myDb.insertData(textInputUserName.getEditText().getText().toString(),
                        textInputPhoneNumber.getEditText().getText().toString(),
                        textInputEmail.getEditText().getText().toString(),
                        textInputPassword.getEditText().getText().toString());
                if(isInserted = true)
                    Toast.makeText(UserActivity.this,"Data Inserted", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(UserActivity.this,"Data not Inserted", Toast.LENGTH_LONG).show();
            }
        });
    }

    private boolean validateUsername() {
        String username = textInputUserName.getEditText().getText().toString().trim();
        if (username.isEmpty()) {
            textInputUserName.setError("Field can't be empty");
            return false;
        } else if (username.length() > 15) {
            textInputUserName.setError("Username too long");
            return false;
        } else {
            textInputUserName.setError(null);
            return true;
        }
    }


    private boolean validatePhoneNumber() {
        String phoneNumberInput = textInputPhoneNumber.getEditText().getText().toString().trim();

        if (phoneNumberInput.isEmpty()) {
            textInputPhoneNumber.setError("Field can't be empty");
            return false;
        } else if (phoneNumberInput.length() > 15) {
            textInputUserName.setError("Username too long");
            return false;
        } else {
            textInputPhoneNumber.setError(null);
            return true;
        }
    }

    private boolean validateEmail() {
        String emailInput = textInputEmail.getEditText().getText().toString().trim();

        if (emailInput.isEmpty()) {
            textInputEmail.setError("Field can't be empty");
            return false;
        } else {
            textInputEmail.setError(null);
            return true;
        }
    }

    private boolean validatePassword() {
        String passwordInput = textInputPassword.getEditText().getText().toString().trim();

        if (passwordInput.isEmpty()) {
            textInputPassword.setError("Field can't be empty");
            return false;
        } else {
            textInputPassword.setError(null);
            return true;
        }
    }
    private boolean validateConfirmPassword() {
        String confirmpasswordInput = textInputPassword.getEditText().getText().toString().trim();
        String pass1 = textInputPassword.getEditText().getText().toString();
        String pass2 = textInputConfirmPassword.getEditText().getText().toString();

        if (confirmpasswordInput.isEmpty()) {
            textInputConfirmPassword.setError("Field can't be empty");
            return false;
        } else if (!confirmpasswordInput.isEmpty() && !pass1.equals(pass2)) {
            Toast pass = Toast.makeText(UserActivity.this,"Passwords don't match", Toast.LENGTH_SHORT);
            pass.show();
            return false;
        } else {
            textInputConfirmPassword.setError(null);
            return true;
        }
    }

    public void confirmInput(View v) {
        String pass1str = textInputPassword.getEditText().getText().toString();
        String pass2str = textInputConfirmPassword.getEditText().getText().toString();
        String unamestr = textInputUserName.getEditText().getText().toString();
        String emailstr = textInputEmail.getEditText().getText().toString();
        String phnostr = textInputPhoneNumber.getEditText().getText().toString();
        if (!validateUsername() | !validatePhoneNumber() | !validateEmail() |  !validatePassword() | !validateConfirmPassword()) {
            return;
        }
        String input = "Username: " + textInputUserName.getEditText().getText().toString();
        input += "\n";
        input += "PhoneNumber: " + textInputPhoneNumber.getEditText().getText().toString();
        input += "\n";
        input = "Email: " + textInputEmail.getEditText().getText().toString();
        input += "\n";
        input += "Password: " + textInputPassword.getEditText().getText().toString();
        input += "\n";
        input += "Confirm Password: " + textInputConfirmPassword.getEditText().getText().toString();

        Toast.makeText(this, input, Toast.LENGTH_SHORT).show();
    }
}
