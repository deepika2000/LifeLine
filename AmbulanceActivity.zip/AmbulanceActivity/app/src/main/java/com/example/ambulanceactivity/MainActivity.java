package com.example.ambulanceactivity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper myDb;
    EditText editUsername, editPassword;
    public TextView text1;
    public Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDb = new DatabaseHelper(this);

        editUsername = (EditText) findViewById(R.id.editText2);
        editPassword = (EditText) findViewById(R.id.editText3);
        b1 = (Button) findViewById(R.id.button);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String uname = editUsername.getText().toString();
                String pass = editPassword.getText().toString();
                boolean chkemailpass = myDb.emailpassword(uname,pass);
                if (chkemailpass == true) {
                    Toast.makeText(getApplicationContext(),"Successfully Login", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(getApplicationContext(),"Wrong Credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });
        init();
    }

    public void init() {
        text1 = (TextView) findViewById(R.id.textView4);
        b1 = (Button) findViewById(R.id.button);
        text1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toy = new Intent(MainActivity.this, OptionsActivity.class);
                startActivity(toy);
            }
        });
    }
}
